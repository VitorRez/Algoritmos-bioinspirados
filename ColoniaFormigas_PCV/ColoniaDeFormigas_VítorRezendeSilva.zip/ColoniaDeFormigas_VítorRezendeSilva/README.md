Para executar o o algoritmo o usuário deve fornecer os seguintes dados de entrada:
- num_iterações
- Q
- p
- f
- a
- b
- Tipo de atualização de feromonios, pode ser "AS" ou "EAS"
Ao executar o algoritmo você deve fornecer os seguintes dados de entrada nesta ordem:
taxa de cruzamento, taxa de mutação, número de gerações, número de indivíduos por geração, o tipo de cruzamento (valores aceitos: "BLXa" ou "BLXab"), variável para decidir se o algoritmo vai ou não gerar um gráfico com o fit de cada geração (valores aceitos: 1 para sim e 0 para não)
ou seja: (tc, tm, n, num_indivíduos, cruzamento, plot)
Além disso será gerado um gráfico demonstrando o comportamento das gerações, e um arquivo gen.txt onde serão registrados os resultados de cada iteração do AG.

Junto ao código está sendo enviado a documentação associada, e dois pdfs, resultado.pdf e resultado2.pdf relativos aos testes realizados e descritos na documentação.
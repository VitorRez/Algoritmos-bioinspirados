Ao executar o algoritmo você deve fornecer como dado de entrada o número de iterações do AG.
Ao fim da execução, será impresso o melhor indivíduo encontrado, o seu valor na função objetivo e o número de iterações.
Além disso será gerado um gráfico demonstrando o comportamento das gerações, e um arquivo gen.txt onde serão registrados
os resultados de cada iteração do AG.